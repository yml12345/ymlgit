'''
@author: yimeiling
@software: SeleniumTest
@file: run.py
@time: 2020/3/26 16:16
@desc:
'''

import unittest
from BeautifulReport import BeautifulReport
from common.config import *
import time

#创建测试集
suite = unittest.TestSuite()
#添加测试用例
discover = unittest.defaultTestLoader.discover(CASE_PATH,pattern='*.py')
#创建执行器，并执行
_time = time.strftime("%Y-%m-%d %H_%M_%S")
filename = "mrsx_{}.html".format(_time)
BeautifulReport(discover).report(description="我在测试每日生鲜APP",
                                 report_dir='report',
                                 filename=filename)
# _time = time.strftime("%Y-%m-%d %H_%M_%S")
# filename = "crm_{}.html".format(_time)
# BeautifulReport(discover).report(description="测试每日生鲜APP",
#                                  report_dir='report',
#                                  filename=filename)

