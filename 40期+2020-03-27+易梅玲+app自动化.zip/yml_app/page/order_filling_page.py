'''
@author: yimeiling
@software: SeleniumTest
@file: order_filling_page.py
@time: 2020/3/25 22:02
@desc:
'''
"""
订单填写页面
"""
from page.base_page import BasePage

class OrderFillingPage(BasePage):
    """
    订单填写页面操作类
    """
    #