'''
@author: yimeiling
@software: SeleniumTest
@file: shopping_cart_page.py
@time: 2020/3/25 19:02
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from page.base_page import BasePage

class ShoppingCartPage(BasePage):
    #定义定位器
    balance_locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_checkout\"]') #定位去结算按钮
    def click_balance(self):
        """
        点击“去结算”
        :return:
        """
        self.find_element(self.balance_locator).click()

