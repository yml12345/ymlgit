'''
@author: yimeiling
@software: SeleniumTest
@file: main_page.py
@time: 2020/3/25 18:15
@desc:
'''
"""
首页页面
"""
from appium.webdriver.common.mobileby import MobileBy as By
from page.base_page import BasePage
class MainPage(BasePage):
    #定义定位器、
    select_locator = (By.XPATH, '//android.widget.FrameLayout[@resource-id=\"cn.missfresh.application:id/search_layout\"]')# 定位首页搜索框
    click_select_locator = (By.XPATH, '//android.widget.EditText[@resource-id=\"cn.missfresh.application:id/search_view\"]')# 定位输入搜索信息框
    new_exclusive_locator = (By.XPATH,'//android.widget.TextView[@text=\"新人专享\"]')#定位新人专享
    red_packet_locator = (By.XPATH, '//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/award_view\"]') #定位新人红包
    new_goods_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/recycler_view\"]/android.widget.RelativeLayout[1]/android.widget.ImageView[1]') #定位新人价商品
    see_more_locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/look_more_tv\"]') #定位查看更多
    preserved_locator = (By.XPATH, '//android.widget.TextView[@text=\"新鲜果蔬\"]') #定位新鲜果蔬
    drink_milk_locator = (By.XPATH, '//android.widget.TextView[@text=\"酒饮乳品\"]') #定位酒饮乳品
    snacks_locator = (By.XPATH, '//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rv_small_diamond\"]/android.widget.LinearLayout[3]/android.widget.TextView[1]')  #定位休闲零食
    daily_necessities_locator = (By.XPATH,'//android.widget.TextView[@text=\"日用百货\"]') #定位日用百货
    grain_food_locator = (By.XPATH, '//android.widget.TextView[@text=\"粮油速食\"]') #定位粮油速食
    my_locator = (By.XPATH, '//android.widget.TextView[@text=\"我的\"]')  #定位“我的”

    def click_select(self):
        """
        点击搜索框
        :return:
        """
        self.find_element(self.select_locator).click()
    def  send_select(self,info):
        """
        在搜索框中输入信息
        :return:
        """
        return self.find_element(self.click_select_locator).send_keys(info)
    def click_new_exclusive(self):
        """
        点击新人专享
        :return:
        """
        self.find_element(self.new_exclusive_locator).click()
    def click_red_packet(self):
        """
        点击新人红包
        :return:
        """
        self.find_element(self.red_packet_locator).click()
    def click_new_goods(self):
        """
        点击新人价商品
        :return:
        """
        self.find_element(self.new_goods_locator).click()
    def click_see_more(self):
        """
        点击查看更多
        :return:
        """
        self.find_element(self.see_more_locator).click()
    def click_preserved(self):
        """
        点击新鲜果蔬
        :return:
        """
        self.find_element(self.preserved_locator).click()
    def click_drink_milk(self):
        """
        点击酒饮乳品
        :return:
        """
        self.find_element(self.drink_milk_locator).click()
    def click_snacks(self):
        """
        点击休闲零食
        :return:
        """
        self.find_element(self.snacks_locator).click()
    def click_daily_necessities(self):
        """
        点击日用百货
        :return:
        """
        self.find_element(self.daily_necessities_locator).click()
    def click_grain_food(self):
        """
        点击粮油速食
        :return:
        """
        self.find_element(self.grain_food_locator).click()
    def click_my(self):
        """
        点击粮油速食
        :return:
        """
        self.find_element(self.my_locator).click()



