'''
@author: yimeiling
@software: SeleniumTest
@file: base_page.py
@time: 2020/3/25 17:42
@desc:
'''
"""
基页面
"""
class BasePage():

    def __init__(self,driver):
        """
        启动app
        :param driver:
        """
        self.driver=driver


    def find_element(self,locator):
        """
        封装find_element
        :param locator:
        :return:
        """
        return self.driver.find_element(*locator)
