'''
@author: yimeiling
@software: SeleniumTest
@file: new_exclusive_page.py
@time: 2020/3/25 18:57
@desc:
'''
"""
新人专享页面
"""
from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class NewExclusivePage(BasePage):
    #定义定位器
    new_exclusive_goods_locator = (By.XPATH,'//android.view.View/android.view.View[2]/android.view.View[1]/android.view.View[5]/android.view.View[1]/android.widget.Image[1]') #定位加入购物车按钮
    shopping_cart_locator = (By.XPATH, '//android.widget.Image[@text=\"购物车图标\"]') #定位购物车图标]
    return_locator = (By.XPATH, '//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/iv_title_bar_left_icon\"]')#定位返回按钮

    def click_new_exclusive_goods(self):
        """
        点击页面第一个商品的加入购物车
        :return:
        """
        self.find_element(self.new_exclusive_goods_locator).click()
    def click_shopping_cart(self):
        """
        点击购物车图标
        :return:
        """
        self.find_element(self.shopping_cart_locator).click()
    def click_return(self):
        """
        点击返回
        :return:
        """
        self.find_element(self.return_locator).click()



