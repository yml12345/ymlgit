'''
@author: yimeiling
@software: SeleniumTest
@file: classify_page.py
@time: 2020/3/26 10:19
@desc:
'''
"""
分类页面
"""
from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class ClassifyPage(BasePage):
    """分类页面操作类"""
    #定义定位器
    grain_taste_locator = (By.XPATH,'//android.widget.TextView[@text=\"粮油调味\"]')
    paper_clean_locator = (By.XPATH,'//android.widget.TextView[@text=\"纸品清洁\"]')
    leisure_snacks_locator = (By.XPATH,'//android.widget.TextView[@text=\"休闲零食\"]')
    rich_wine_locator = (By.XPATH,'//android.widget.TextView[@text=\"酒饮冲调\"]')
    seasonal_fruits_locator = (By.XPATH,'//android.widget.TextView[@text=\"时令水果\"]')
    def text_grain_taste(self):
        """
        返回分类页面中休闲零食的文本信息
        :return:
        """
        return self.find_element(self.grain_taste_locator).text
    def text_paper_clean(self):
        """
        返回纸品清洁文本内容
        :return:
        """
        return self.find_element(self.paper_clean_locator).text
    def text_leisure_snacks(self):
        """
        返回休闲零食文本内容
        :return:
        """
        return self.find_element(self.leisure_snacks_locator).text
    def text_rich_wine(self):
        """
        返回酒饮冲调文本内容
        :return:
        """
        return self.find_element(self.rich_wine_locator).text
    def text_seasonal_fruits(self):
        """
        返回时令水果文本内容
        :return:
        """
        return self.find_element(self.seasonal_fruits_locator).text

