'''
@author: yimeiling
@software: SeleniumTest
@file: my_page.py
@time: 2020/3/26 20:21
@desc:
'''
"""
我的页面
"""
from page.base_page import BasePage
from appium.webdriver.webdriver import MobileBy as By
class MyPage(BasePage):
    """
    我的页面操作类
    """
    #定位器
    group_booking_locator = (By.XPATH,'/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.View/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[2]/android.widget.TextView') #定位我的拼团按钮

    def click_group_booking(self):
        """
        点击我的拼团
        :return:
        """
        self.find_element(self.group_booking_locator).click()