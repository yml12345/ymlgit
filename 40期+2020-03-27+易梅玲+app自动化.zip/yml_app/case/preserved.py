'''
@author: yimeiling
@software: SeleniumTest
@file: preserved.py
@time: 2020/3/26 9:29
@desc:
'''
"""
验证点击“新鲜果蔬”，页面跳转到时令水果，且展示的是关于水果的商品信息
"""
from case.base_case import BaseCase
from page.main_page import MainPage
import unittest
from time import sleep
from page.classify_page import ClassifyPage
class Preserved(BaseCase):
    """
    新鲜果蔬操作类
    """
    def test_preserved(self):
        """
        新鲜果蔬
        测试用例编号：ST-SY-07
        :return:
        """
        a = "时令水果"
        # 点击新鲜果蔬，进入分类页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_preserved()
        sleep(5)
        #断言
        cp = ClassifyPage(self.driver)
        b = cp.text_seasonal_fruits()
        self.assertEqual(a,b)

if __name__ == '__main__':
    unittest.main()