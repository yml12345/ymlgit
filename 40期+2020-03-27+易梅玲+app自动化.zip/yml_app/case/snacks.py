'''
@author: yimeiling
@software: SeleniumTest
@file: snacks.py
@time: 2020/3/26 9:56
@desc:
'''
"""
验证点击“休闲零食”，页面跳转到休闲零食，且展示的是关于零食的商品信息
"""
from case.base_case import BaseCase
from page.main_page import MainPage
import unittest
from time import sleep
from page.classify_page import ClassifyPage
class Snacks(BaseCase):
    """
    休闲零食操作类
    """
    def test_snacks(self):
        """
        休闲零食
        测试用例编号：ST-SY-09
        :return:
        """
        a = "休闲零食"
        # 点击休闲零食，进入分类页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_snacks()
        sleep(5)
        #断言
        cp = ClassifyPage(self.driver)
        b = cp.text_leisure_snacks()
        self.assertEqual(a,b)

if __name__ == '__main__':
    unittest.main()