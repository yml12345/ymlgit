'''
@author: yimeiling
@software: SeleniumTest
@file: see_more.py
@time: 2020/3/25 22:43
@desc:
'''
"""
验证查看更多
"""
from case.base_case import BaseCase
from page.main_page import MainPage
from page.new_exclusive_page import NewExclusivePage
from page.shopping_cart_page import ShoppingCartPage
import unittest
from time import sleep
import ddt
from common.utils import get_excel
from common.logger import Logger
logger = Logger().logger

@ddt.ddt
class SeeMore(BaseCase):
    """
    查看更多操作类
    """
    @ddt.data(*get_excel("activity.xlsx"))
    @ddt.unpack
    def test_see_new(self,order_activity):
        """
        查看更多
        测试用例编号：ST-SY-05
        :return:
        """
        # a = "cn.missfresh.module.order.orderconfirm.view.OrderConfirmationActivity"
        # 点击新人价商品，进入新人专享页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_see_more()
        sleep(5)
        # 点击加入购物车按钮
        nep = NewExclusivePage(self.driver)
        nep.click_new_exclusive_goods()
        sleep(5)
        # 点击购物车,进入购物车页面
        nep.click_shopping_cart()
        sleep(5)
        # 点击结算，进入订单填写页面
        scp = ShoppingCartPage(self.driver)
        scp.click_balance()
        sleep(5)
        #断言
        b = self.driver.current_activity
        logger.info(b)
        self.assertEqual(order_activity,b)

if __name__ == '__main__':
    unittest.main()
