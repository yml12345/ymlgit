'''
@author: yimeiling
@software: SeleniumTest
@file: new_exclusive.py
@time: 2020/3/25 21:50
@desc:
'''
"""
验证新人专享功能
"""
from case.base_case import BaseCase
from page.main_page import MainPage
from page.new_exclusive_page import NewExclusivePage
from page.shopping_cart_page import ShoppingCartPage
import unittest
from time import sleep
from common.utils import get_excel
import ddt
from common.logger import Logger
logger = Logger().logger

@ddt.ddt
class NewExclusive(BaseCase):
    """
    新人专享操作类
    """

    @ddt.data(*get_excel("activity.xlsx"))
    @ddt.unpack
    def test_new_exclusive(self,order_activity):
        """
        新人专享
        测试用例编号：ST-SY-02
        :return:
        """
        # 点击新人专享，进入新人专享页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_new_exclusive()
        sleep(5)
        # 点击加入购物车按钮
        nep = NewExclusivePage(self.driver)
        nep.click_new_exclusive_goods()
        sleep(5)
        # 点击购物车,进入购物车页面
        nep.click_shopping_cart()
        sleep(5)
        # 点击结算，进入订单填写页面
        scp = ShoppingCartPage(self.driver)
        scp.click_balance()
        sleep(5)
        # 断言
        b = self.driver.current_activity
        logger.info(b)
        self.assertEqual(order_activity, b)
if __name__ == '__main__':
    unittest.main()
