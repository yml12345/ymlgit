'''
@author: yimeiling
@software: SeleniumTest
@file: base_case.py
@time: 2020/3/25 18:01
@desc:
'''
import unittest
from common.driver import driver

class BaseCase(unittest.TestCase):

    def setUp(self):
        self.driver = driver()



    def tearDown(self):
        self.driver.quit()


