'''
@author: yimeiling
@software: SeleniumTest
@file: group_booking.py
@time: 2020/3/26 20:15
@desc:
'''
"""
在我的页面点击我的拼团，验证跳转到我的拼团页面
"""
from case.base_case import BaseCase
from time import sleep
from page.my_page import MyPage
from page.main_page import MainPage
import unittest
from common.logger import Logger
logger = Logger().logger

class GroupBooking(BaseCase):
    """
    我的拼团操作类
    """
    def test_group_booking(self):
        """
        点击我的拼团，页面跳转到我的拼团页面
        :return:
        """
        a = "cn.missfresh.module.promotion.h5.view.H5Activity"
        self.driver.implicitly_wait(30)
        #点击“我的”，进入“我的页面”
        mp = MainPage(self.driver)
        mp.click_my()
        sleep(5)
        #点击“我的拼团”，进入我的拼团页面
        map = MyPage(self.driver)
        map.click_group_booking()
        sleep(5)
        #断言
        b =self.driver.current_activity
        logger.info(b)
        self.assertEqual(a,b)


if __name__ == '__main__':
    unittest.main()