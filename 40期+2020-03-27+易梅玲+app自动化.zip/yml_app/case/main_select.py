'''
@author: yimeiling
@software: SeleniumTest
@file: main_select.py
@time: 2020/3/25 21:23
@desc:
'''
"""
首页搜索
"""
from case.base_case import BaseCase
from page.main_page import MainPage
import unittest
from time import sleep
from common.logger import Logger
logger = Logger().logger
class MainSelect(BaseCase):
    """
    首页搜索操作类
    """
    def test_main_select(self):
        """
        首页搜索
        测试用例编号：ST-SY-01
        :param self:
        :return:
        """
        select_activity = "cn.missfresh.module.product.search.view.SearchActivity"
        info = "苹果"
        #点击搜索框
        self.driver.implicitly_wait(60)
        mp = MainPage(self.driver)
        mp.click_select()
        sleep(5)
        mp.send_select(info)
        sleep(5)
        self.driver.keyevent(66)
        sleep(5)
        #断言
        a = self.driver.current_activity
        logger.info(a)
        self.assertEqual(select_activity,a)


if __name__ == '__main__':
    unittest.main()





