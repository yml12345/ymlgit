'''
@author: yimeiling
@software: SeleniumTest
@file: grain_food.py
@time: 2020/3/26 10:08
@desc:
'''
"""
验证点击“粮油速食”，页面跳转到粮油调味，且展示的是关于油、调味品等商品信息
"""
from case.base_case import BaseCase
from page.main_page import MainPage
from page.classify_page import ClassifyPage
import unittest
from time import sleep
from common.logger import Logger
logger = Logger().logger
class GrainFood(BaseCase):
    """
    粮油速食操作类
    """
    def test_grain_food(self):
        """
        粮油速食
        测试用例编号：ST-SY-11
        :return:
        """
        a = "粮油调味"
        # 点击粮油速食，进入分类页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_grain_food()
        sleep(5)
        #断言
        cp = ClassifyPage(self.driver)
        b = cp.text_grain_taste()
        logger.info(b)
        self.assertEqual(a,b)


if __name__ == '__main__':
    unittest.main()