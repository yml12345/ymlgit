'''
@author: yimeiling
@software: SeleniumTest
@file: new_exclusive_return.py
@time: 2020/3/25 22:47
@desc:
'''
"""
验证新人专享页面返回功能
"""
from case.base_case import BaseCase
from page.main_page import MainPage
from page.new_exclusive_page import NewExclusivePage
from page.shopping_cart_page import ShoppingCartPage
import unittest
from time import sleep
from common.logger import Logger
logger = Logger().logger
class NewExclusiveReturn(BaseCase):
    """
    新人专享返回操作类
    """

    def test_new_exclusive_return(self):
        """
        新人专享
        测试用例编号：ST-SY-06
        :return:
        """

        # 点击新人专享，进入新人专享页面
        self.driver.implicitly_wait(30)
        sleep(10)
        a = self.driver.current_activity
        logger.info(a)
        mp = MainPage(self.driver)
        mp.click_new_exclusive()
        sleep(10)
        # 点击返回按钮
        nep =NewExclusivePage(self.driver)
        nep.click_return()
        sleep(10)
        #断言
        b = self.driver.current_activity
        logger.info(b)
        self.assertEqual(a,b)



if __name__ == '__main__':
    unittest.main()
