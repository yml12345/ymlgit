'''
@author: yimeiling
@software: SeleniumTest
@file: daily_necessities.py
@time: 2020/3/26 10:00
@desc:
'''
"""
验证点击“日用百货”，页面跳转到纸品清洁，且展示的是关于纸和清洁用品的商品信息
"""
from case.base_case import BaseCase
from page.main_page import MainPage
import unittest
from time import sleep
from page.classify_page import ClassifyPage
from common.logger import Logger
logger = Logger().logger
class DailyNecessitties(BaseCase):
    """
    日用百货操作类
    """
    def test_daily_necessitties(self):
        """
        日用百货
        测试用例编号：ST-SY-10
        :return:
        """
        a = "纸品清洁"
        # 点击日用百货，进入分类页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_daily_necessities()
        sleep(5)
        #断言
        cp = ClassifyPage(self.driver)
        b = cp.text_paper_clean()
        logger.info(b)
        self.assertEqual(a, b)

if __name__ == '__main__':
    unittest.main()
