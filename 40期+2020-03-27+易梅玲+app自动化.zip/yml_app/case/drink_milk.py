'''
@author: yimeiling
@software: SeleniumTest
@file: drink_milk.py
@time: 2020/3/26 9:46
@desc:
'''
"""
验证点击“酒饮乳品”，页面跳转到酒饮冲调，且展示的是关于酒水和饮料的商品信息
"""
from case.base_case import BaseCase
from page.main_page import MainPage
import unittest
from time import sleep
from page.classify_page import ClassifyPage
class DrinkMilk(BaseCase):
    """
    酒饮乳品操作类
    """
    def test_drink_milk(self):
        """
        酒饮乳品
        测试用例编号：ST-SY-08
        :return:
        """
        a = "酒饮冲调"
        # 点击酒饮乳品，进入分类页面
        self.driver.implicitly_wait(30)
        mp = MainPage(self.driver)
        mp.click_drink_milk()
        sleep(5)
        #断言
        cp = ClassifyPage(self.driver)
        b = cp.text_rich_wine()
        self.assertEqual(a,b)

if __name__ == '__main__':
    unittest.main()
