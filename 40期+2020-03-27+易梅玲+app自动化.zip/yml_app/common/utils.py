'''
@author: yimeiling
@software: SeleniumTest
@file: utils.py
@time: 2020/3/24 17:14
@desc:
'''
# 获得机器屏幕大小x,y
from appium.webdriver.common.touch_action import TouchAction
import xlrd
import os
from common.config import *
from common.logger import Logger
logger = Logger().logger

def get_excel(filename):
	f = os.path.join(DATA_PATH,filename)
	data = xlrd.open_workbook(f)
	table = data.sheet_by_index(0)
	nrows = table.nrows
	l_list = []
	for r in range(nrows):
		a = tuple(table.row_values(r))
		l_list.append(a)
	return (l_list[1:])

logger.info(get_excel("activity.xlsx"))
def getSize(dr):
	x = dr.get_window_size()['width']
	y = dr.get_window_size()['height']
	return (x, y)  #(720,1280)


# 屏幕向上滑动
def swipeUp(dr, t):
	l = getSize(dr) #(720,1280)
	x1 = int(l[0] * 0.5)  # x坐标  360
	y1 = int(l[1] * 0.75)  # 起始y坐标  960
	y2 = int(l[1] * 0.25)  # 终点y坐标  320
	dr.swipe(x1, y1, x1, y2, t)


# 屏幕向下滑动
def swipeDown(dr, t):
	l = getSize(dr)
	x1 = int(l[0] * 0.5)  # x坐标
	y1 = int(l[1] * 0.25)  # 起始y坐标  320
	y2 = int(l[1] * 0.75)  # 终点y坐标  960
	dr.swipe(x1, y1, x1, y2, t)


# 屏幕向左滑动
def swipLeft(dr, t):
	l = getSize(dr)
	x1 = int(l[0] * 0.75)
	y1 = int(l[1] * 0.5)
	x2 = int(l[0] * 0.05)
	dr.swipe(x1, y1, x2, y1, t)


# 屏幕向右滑动
def swipRight(dr, t):
	l = getSize(dr)
	x1 = int(l[0] * 0.05)
	y1 = int(l[1] * 0.5)
	x2 = int(l[0] * 0.75)
	dr.swipe(x1, y1, x2, y1, t)


# 屏幕快速向右滑动
def flickSwipRight(dr):
	l = getSize(dr)
	x1 = int(l[0] * 0.05)
	y1 = int(l[1] * 0.5)
	x2 = int(l[0] * 0.75)
	dr.flick(x1, y1, x2, y1)


def jiugongge(dr,s_list):
	x = dr.get_window_size()['width']
	y = dr.get_window_size()['height']
	p_list = [[x*0.25,y*0.25],[x*0.5,y*0.25],[x*0.75,y*0.25],
              [x*0.25,y*0.5],[x*0.5,y*0.5],[x*0.75,y*0.5],
              [x*0.25,y*0.75],[x*0.5,y*0.75],[x*0.75,y*0.75]]
	action = TouchAction(dr)
	action.press(x=p_list[s_list[0]-1][0],y=p_list[s_list[0]-1][1])
	for i in range(1,len(s_list)):
		x = p_list[s_list[i]-1][0]
		y = p_list[s_list[i]-1][1]
		action.wait(2000)
		action.move_to(x=x,y=y)
	action.release()
	action.perform()
