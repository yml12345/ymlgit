'''
@author: yimeiling
@software: SeleniumTest
@file: driver.py
@time: 2020/3/25 21:12
@desc:
'''
from appium import webdriver
from common.config import HOST,DESIRED_CAPABILITIES

def driver():
    driver = webdriver.Remote(HOST,DESIRED_CAPABILITIES)
    return driver


