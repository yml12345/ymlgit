'''
@author: yimeiling
@software: SeleniumTest
@file: config.py
@time: 2020/3/25 21:10
@desc:
'''
import os

FILE_PATH= os.path.abspath(__file__)
B_PATH = os.path.dirname(FILE_PATH)
BASE_PATH = os.path.dirname(B_PATH)
CASE_PATH= os.path.join(BASE_PATH,"case")
COMMON_PATH= os.path.join(BASE_PATH,"common")
DATA_PATH = os.path.join(BASE_PATH,"data")
PAGE_PATH = os.path.join(BASE_PATH,"page")
HOST = "http://localhost:4723/wd/hub"
LOG_PATH = os.path.join(BASE_PATH,"log")
DESIRED_CAPABILITIES = {
    'platformName': 'Android',
    'deviceName': '127.0.0.1:62001',
    'platformVersion': '5.1.1',
    'appPackage': 'cn.missfresh.application',
    'appActivity': 'cn.missfresh.module.base.main.view.SplashActivity',
    'noReset': True
}