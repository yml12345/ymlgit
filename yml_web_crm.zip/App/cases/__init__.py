'''
@author: zhangqiuting
@software: Appium
@file: __init__.py.py
@time: 2020/3/24 22:35
@desc:
'''