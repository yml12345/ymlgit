'''
@author: zhangqiuting
@software: SeleniumTest
@file: test1.py
@time: 2020/3/23 20:47
@desc:
'''
from appium import webdriver
from appium.webdriver.common.mobileby import By
from common import swipe

desired_capabilities = {
    'platformName': 'Android',
    'deviceName': '127.0.0.1:62001',
    'platformVersion': '5.1.1',
    'appPackage': 'com.tencent.news',
    'appActivity': 'com.tencent.news.activity.SplashActivity',
    'noReset': True,
    'newCommandTimeout': 600
}

driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_capabilities)
# locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"com.tencent.news:id/am_\"]')
# element = driver.find_element(*locator)
# element.click()
# input_element = driver.find_element(By.XPATH, '//android.widget.EditText[@resource-id=\"com.tencent.news:id/bvg\"]')
# input_element.send_keys("肺炎")
# driver.press_keycode(66)
# driver.keyevent(4, metastate=None)
# driver.hide_keyboard()
# driver.wait_activity("cn.missfresh.module.base.main.view.MainActivity", 3)
# print(driver.current_activity)

# print(driver.get_window_size())

swipe.unlock(driver, 225, 400, 225, [1, 2, 3, 5, 7, 8, 9])

'''
{
    "platformName": "Android",
    "deviceName": "127.0.0.1:62001",
    "platformVersion": "5.1.1",
    "appPackage": "cn.missfresh.application",
    "appActivity": "cn.missfresh.module.base.main.view.SplashActivity",
    "noReset": true
}
'''
import json

print(json.dumps(desired_capabilities))