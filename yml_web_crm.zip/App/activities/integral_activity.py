'''
@author: zhangqiuting
@software: Appium
@file: integral_activity.py
@time: 2020/3/26 11:34
@desc:
'''
from activities.splash_activity import SplashActivity

class IntegralActivity(SplashActivity):
    '''
    积分兑换页面
    '''
