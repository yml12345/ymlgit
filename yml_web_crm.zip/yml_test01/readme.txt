1、修改common下config.py中的HOST
2、修改run.py中的lp.login("admin","hd123456")
3、修改permission_assignment.py中的lp.login("admin","hd123456")  （第80行）
4、修改data下的userinfo,xlsx
5、在系统中创建一个客户名称为“客户名称”的客户信息
6、在系统中添加用户信息，注意部门选择“办公室”，岗位选择“CEO”,密码为“123456”
