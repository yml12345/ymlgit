'''
@author: yimeiling
@software: SeleniumTest
@file: file.py
@time: 2020/3/19 22:57
@desc:
'''
"""文件操作"""
import os

#判断文件是否在某目录下


def file_exists_path(file,path):
    """
    判断文件是否存在,存在就进行删除操作
    :param filename: 文件的路径
    :return:
    """
    filename = "{}\{}".format(path,file)
    if os.path.exists(filename):
        os.remove(filename)
    else:
        return "该文件{}在{}下不存在".format(file,path)

