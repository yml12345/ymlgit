'''
@author: yimeiling
@software: SeleniumTest
@file: test.py
@time: 2020/3/23 11:06
@desc:
'''

p1_list = [1,2,3,4,5]
p_list = "['客户', '商机', '合同', '财务', '更多']"

p2 = list(p_list)
print(p2)
for p in p2:
    print(p)
