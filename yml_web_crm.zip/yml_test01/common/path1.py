'''
@author: yimeiling
@software: SeleniumTest
@file: path1.py
@time: 2020/3/20 15:16
@desc:
'''
from pathlib import Path

a = Path(__file__).absolute()  #获取当前文件的绝对路径
a1 = a.parent  #获取a文件的目录路径
BASE_PATH = a1.parent  #获取a文件的上一层目录路径
p = Path(BASE_PATH)
CASE_PATH = p.joinpath("case")
DATA_PATH = p.joinpath("data")
COMMON_PATH = p.joinpath("common")
PAGE_PATH = p.joinpath("page")
LOG_PATH = p.joinpath("log")

