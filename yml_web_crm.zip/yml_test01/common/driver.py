"""
打开浏览器
"""
from selenium import webdriver

def chrome():
    """
    谷歌浏览器
    :return:
    """
    driver = webdriver.Chrome()
    driver.maximize_window()
    return driver