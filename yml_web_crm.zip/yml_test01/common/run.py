'''
@author: yimeiling
@software: SeleniumTest
@file: run.py
@time: 2020/3/20 16:35
@desc:
'''
"""
执行用例
"""
import unittest
import time
from common.driver import chrome
from page.login_page import LoginPage
from common.util import create_cookie
from common.config import *
import os
from common.logger import Logger
from BeautifulReport import BeautifulReport

#获取cookies，并将cookies存放到配置文件config.ini中
try:
    lp = LoginPage(chrome())
    lp.open()
    lp.login("admin","hd123456")
    cookies = lp.get_cookies()
    cookies = create_cookie(cookies[0])
    print(cookies)
    filename = os.path.join(DATA_PATH,"config.ini")
    with open(filename,"w",encoding="utf-8") as f :
        f.write(str(cookies))
    lp.quit()
except Exception as e:
    raise


# 创建测试集
# 创建测试集
suite = unittest.TestSuite()
#添加测试用例
logger = Logger().logger
discover = unittest.defaultTestLoader.discover(CASE_PATH,pattern='*.py')
#创建执行器，并执行
_time = time.strftime("%Y-%m-%d %H_%M_%S")
filename = "crm_{}.html".format(_time)
BeautifulReport(discover).report(description="我在测试CRM",
                                 report_dir='report',
                                 filename=filename)
