import xlrd
import csv
from common.config import *
import os
from common.logger import Logger
logger = Logger().logger


def get_data_from_txt(filename):
    # f = os.path.join(DATA_PATH,filename)
    f = "{}\{}".format(DATA_PATH, filename)
    with open(f,'r',encoding='utf-8') as f :
        data = f.readline()
        return tuple(data.split(","))

logger.info(get_data_from_txt("userinfo.txt"))

def get_data_from_excel(filename):
    # f = os.path.join(DATA_PATH,filename)
    f = "{}\{}".format(DATA_PATH, filename)
    data = xlrd.open_workbook(f)
    table = data.sheet_by_index(0)  #打开第一个分页
    nrows = table.nrows
    ncols = table.ncols
    table_list = []
    for r in range(nrows):
        t = tuple(table.row_values(r))
        table_list.append(t)
    return table_list[1:]
logger.info(get_data_from_excel("userinfo.xlsx"))


def get_data_from_csv(filename):
    # f = os.path.join(DATA_PATH,filename)
    f = "{}\{}".format(DATA_PATH,filename)
    with open(f,'r',encoding='utf-8') as f:
        data = csv.reader(f)
        list_user = []
        for user in data:
            list_user.append(tuple(user))
        return list_user[1:]
        # for user in data:
        #     dct = {}
        #     dct["username"] = user[0]
        #     dct["password"] = user[1]
        #     list_user.append(dct)
        # return list_user[1:]



logger.info(get_data_from_csv("userinfo.csv"))

def create_cookie(dct,keys = None,default=None):
    """
    传入web返回的cookies,提取name 和 value 并组成字典
    :param dct:
    :param keys:
    :param default:
    :return:
    """
    if keys is None:
        keys = ["name","value"]
        dt = {}
        for key in keys:
            dt [key] = dct.get(key)   #将dct字典中key的值赋值给dt的key
        return dt


def get_cookies(filename):
    file = os.path.join(DATA_PATH,filename)
    with open(file, "r+", encoding="utf-8") as f:
        cookies = f.readline()
        return  eval(cookies)

logger.info(get_cookies("config.ini"))


