'''
@author: yimeiling
@software: SeleniumTest
@file: path.py
@time: 2020/3/20 14:33
@desc:
'''
import os


path = os.path.realpath(__file__)  # 获取当前文件所在的路径
DIR = os.path.dirname(path)  # 获取文件所在的目录
BASE_PATH = os.path.dirname(DIR) # 获取文件所在的上一层目录
CASE_PATH = os.path.join(BASE_PATH,"case")  #路径拼接
DATA_PATH = os.path.join(BASE_PATH,"data")
COMMON_PATH = os.path.join(BASE_PATH,"common")
PAGE_PATH = os.path.join(BASE_PATH,"page")
LOG_PATH = os.path.join(BASE_PATH,"log")
HOST = r"http://192.168.1.16"
HOSTS = HOST+"/crm"

ADD_OPPORTUNITY_URL= HOST+"/crm/index.php?m=business&a=add"
# print(ADD_OPPORTUNITY_URL)
DELETE_MORE_RECYCLED_URL = HOST+"/crm/index.php?m=business&a=index&by=deleted"
OPPORTUNITY_URL = HOST+"/crm/index.php?m=business"
PERMISSION_ASSIGNMENT_URL = HOST+"/crm/index.php?m=user&a=role"



