"""基类测试用例"""
import unittest
from common.driver import chrome
from common.util import get_cookies
from common.config import *



class BaseCase(unittest.TestCase):
    """测试用例基类"""
    def setUp(self):
        """调用谷歌启动"""
        self.driver = chrome()
        self.driver.get(HOST)
        self.driver.add_cookie(get_cookies("config.ini"))

    def tearDown(self):
        """关闭浏览器启动"""
        self.driver.quit()
