"""
从商机查看详情页面中进行添加任务操作
"""
from case.base_case import BaseCase
from time import sleep
from page.opportunity_page import OpportunityPage
from page.add_opportunity_page import AddOpportunityPage
from page.select_customer_page import SelectCustomerPage
from page.see_opportunity_page import SeeOpportunityPage
from page.task_page import TaskPage
from page.add_task_page import AddTaskPage
from common.util import get_data_from_excel
import ddt
from common.config import *

@ddt.ddt
class SeeOpportunitiesAddTask(BaseCase):
    """从商机详情页面中进行添加任务操作类"""

    @ddt.data(*get_data_from_excel("see_opportunities_add_task.xlsx"))
    @ddt.unpack
    def test_see_opportunities_add_task(self,opportunity_name,customer,anticipated_price,theme_name):
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        # 点击对应的查看，进入查看详情页面
        op = OpportunityPage(self.driver)
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        #点击“添加任务”按钮，进入添加任务页面
        sop = SeeOpportunityPage(self.driver)
        sop.click_add_task()
        sleep(3)
        #在添加任务页面，填写相关信息
        atp = AddTaskPage(self.driver)
        atp.send_theme(theme_name)
        #点击保存
        atp.click_save()
        sleep(3)
        # 点击“添加任务”按钮，进入添加任务页面
        sop = SeeOpportunityPage(self.driver)
        sop.click_add_task()
        sleep(3)
        # 在添加任务页面，填写相关信息
        atp = AddTaskPage(self.driver)
        atp.send_theme(theme_name)
        # 点击保存
        atp.click_save()
        sleep(3)
        #断言，判断该任务是否添加成功
        #点击任务，跳转到相关任务页面
        sop.click_task()
        tp = TaskPage(self.driver)
        sleep(5)
        t_list = tp.get_td_text()
        sleep(5)
        self.assertIn(theme_name,t_list)




