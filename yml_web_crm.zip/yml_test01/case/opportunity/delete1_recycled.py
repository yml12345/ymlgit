"""
删除回收站商机信息
"""
# import unittest
from case.base_case import BaseCase
from time import sleep
from page.opportunity_page import OpportunityPage
from page.recycled_page import RecycledPage
from page.add_opportunity_page import AddOpportunityPage
from page.select_customer_page import SelectCustomerPage
from common.util import get_data_from_excel
from page.see_opportunity_page import SeeOpportunityPage
import ddt
from common.logger import Logger
from common.config import *

logger = Logger().logger

@ddt.ddt
class DeleteRecycled(BaseCase):
    @ddt.data(*get_data_from_excel("delete1_recycled.xlsx"))
    @ddt.unpack
    def test_delete_one_recycled(self,opportunity_name,anticipated_price,customer):
        """
        删除回收站一条商机
        测试用例编号：CRM-ST-SHJH-006
        """
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(2)
        # 点击对应的查看按钮，查看商机的详情信息
        op = OpportunityPage(self.driver)
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        # 点击删除按钮
        sop = SeeOpportunityPage(self.driver)
        sop.click_delete()
        sleep(2)
        alert = op.alert()
        alert.accept()
        sleep(2)
        #点击回收站，进入回收站页面
        op = OpportunityPage(self.driver)
        op.click_recycled()
        #勾选并删除一条商机信息
        rp = RecycledPage(self.driver)
        rp.click_one_recycled(opportunity_name)
        rp.click_delete()
        sleep(5)
        alert = rp.alert()
        alert.accept()
        sleep(4)
        #断言
        recycled_list = rp.get_recycled_list()
        logger.info(recycled_list)
        self.assertNotIn(opportunity_name,recycled_list)


    def test_delete_more_recycled(self):
            """
            同时勾选当前页面的所有，并进行删除操作
            测试用例编号：
            """
            rp = RecycledPage(self.driver,DELETE_MORE_RECYCLED_URL)
            rp.open()
            recycled1 = len(rp.get_recycled_list())
            logger.info(recycled1)
            # 进行“商机删除”操作
            rp.click_more_recycled()
            sleep(2)
            rp.click_delete()
            sleep(2)
            alert = rp.alert()
            alert.accept()
            sleep(2)
            # 断言，判断是否删除成功
            recycled2 = len(rp.get_recycled_list())
            logger.info(recycled2)
            self.assertNotEqual(recycled1,recycled2)












