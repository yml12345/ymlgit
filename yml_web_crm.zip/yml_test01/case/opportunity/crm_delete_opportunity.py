"""
删除商机
"""
from case.base_case import BaseCase
from time import sleep
from page.opportunity_page import OpportunityPage
from page.see_opportunity_page import SeeOpportunityPage
from page.select_customer_page import SelectCustomerPage
from page.add_opportunity_page import AddOpportunityPage
from common.util import get_data_from_excel
import ddt
from common.logger import Logger
from common.config import *

logger = Logger().logger



@ddt.ddt
class DeleteOpportunity(BaseCase):
    @ddt.data(*get_data_from_excel("delete1_opportunity.xlsx"))
    @ddt.unpack
    def test_delete_one_opportunity(self,opportunity_name,anticipated_price,customer):
        """勾选第一个进行删除操作"""
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        #进行“商机删除”操作
        op = OpportunityPage(self.driver)
        op.click_one_opportunity()
        op.click_delete()
        sleep(2)
        alert = op.alert()
        alert.accept()
        sleep(2)
        #断言，判断是否删除成功
        opportunity_list = op.get_opportunity_list()
        logger.info(opportunity_list)
        self.assertNotIn(opportunity_name, opportunity_list)
        # opportunity = op.get_opportunity_text()
        # self.assertNotIn(opportunity_name,opportunity)


    def test_delete_more_opportunity(self):
        """
        同时勾选当前页面的所有，并进行删除操作
        测试用例编号：CRM-ST-SHJH-004
        """
        op = OpportunityPage(self.driver,OPPORTUNITY_URL)
        op.open()
        #先获取列表中的所有商机总条数
        opportunity1 = len(op.get_opportunity_list())
        logger.info(opportunity1)
        #进行“商机删除”操作
        op.click_more_opportunity()
        sleep(2)
        op.click_delete()
        sleep(2)
        alert = op.alert()
        alert.accept()
        sleep(2)
        #断言，判断是否删除成功
        opportunity2 = len(op.get_opportunity_list())
        logger.info(opportunity2)
        self.assertNotEqual(opportunity1,opportunity2)

    @ddt.data(*get_data_from_excel("delete3_opportunity.xlsx"))
    @ddt.unpack
    def test_see_delete_opportunity(self,opportunity_name,anticipated_price,customer):
        """去查看详情页面删除商机"""
        # 进行登录操作
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        #输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(2)
        # 点击对应的查看按钮，查看商机的详情信息
        op = OpportunityPage(self.driver)
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        #点击删除按钮
        sop = SeeOpportunityPage(self.driver)
        sop.click_delete()
        sleep(2)
        alert = op.alert()
        alert.accept()
        sleep(2)
        #断言
        opportunity_list = op.get_opportunity_list()
        logger.info(opportunity_list)
        self.assertNotIn(opportunity_name,opportunity_list)











