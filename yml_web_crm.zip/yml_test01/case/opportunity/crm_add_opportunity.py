"""
添加商机
"""
from case.base_case import BaseCase
from time import sleep
import ddt
from page.opportunity_page import OpportunityPage
from page.add_opportunity_page import AddOpportunityPage
from page.select_customer_page import SelectCustomerPage
from common.util import get_data_from_excel
import os
from common.config import *

@ddt.ddt
class AddOpportunity(BaseCase):
    @ddt.data(*get_data_from_excel("add_opportunity.xlsx"))
    @ddt.unpack
    def test_add_opportunity(self,opportunity_name,anticipated_price,customer):
        """
        添加商品
        :param opportunity_name:商机名
        :param anticipated_price:预计价格
        :param customer:客户名称
        :return:
        """
        aop = AddOpportunityPage(self.driver,ADD_OPPORTUNITY_URL)
        aop.open()
        #输入相关信息
        aop.click_customer()  #点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer) #选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        #点击“保存”按钮
        aop.click_save()
        #断言,判断商机信息是否添加成功
        op = OpportunityPage(self.driver)
        opportunity = op.get_opportunity_text()
        self.assertEqual(opportunity_name,opportunity)












