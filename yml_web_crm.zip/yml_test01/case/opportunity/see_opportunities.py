"""
查看商机详情信息
"""
from case.base_case import BaseCase
from time import sleep
from page.opportunity_page import OpportunityPage
from page.see_opportunity_page import SeeOpportunityPage
from page.add_opportunity_page import AddOpportunityPage
from page.select_customer_page import SelectCustomerPage
import ddt
from common.util import get_data_from_excel
from common.config import *

@ddt.ddt
class SeeOpportunities(BaseCase):
    @ddt.data(*get_data_from_excel("see_opportunities.xlsx"))
    @ddt.unpack
    def test_see_opportunities(self,opportunity_name,customer,anticipated_price):
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(4)
        #点击对应的查看按钮，查看商机的详情信息
        op = OpportunityPage(self.driver)
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        #断言,根据商机名进行判断
        sop = SeeOpportunityPage(self.driver)
        opportunity_name1 = sop.get_opportunity_name_text()
        self.assertEqual(opportunity_name,opportunity_name1)













