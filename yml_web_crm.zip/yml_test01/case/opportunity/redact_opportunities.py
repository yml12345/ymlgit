"""
编辑商机页面
"""
from case.base_case import BaseCase
from time import sleep
from page.opportunity_page import OpportunityPage
from page.select_customer_page import SelectCustomerPage
from page.add_opportunity_page import AddOpportunityPage
from page.redact_opportunities_page import RedactOpportunitiesPage
import ddt
from common.util import get_data_from_excel
from common.config import *

@ddt.ddt
class RedactOpportunities(BaseCase):
    """编辑商机"""
    @ddt.data(*get_data_from_excel("redact_opportunities.xlsx"))
    @ddt.unpack
    def test_redact_opportunities(self,opportunity_name,anticipated_price,customer,opportunity_type_text,status_text):
        """编辑商机"""
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(4)
        #点击对应的编辑按钮
        op = OpportunityPage(self.driver)
        op.click_redact(opportunity_name)
        #进入编辑页面，进行相应的编辑操作
        rp = RedactOpportunitiesPage(self.driver)
        sleep(4)
        select_opportunity_type = rp.select(rp.opportunity_type_locator)
        select_opportunity_type.select_by_visible_text(opportunity_type_text)
        sleep(4)
        select_status = rp.select(rp.status_locator)
        select_status.select_by_visible_text(status_text)
        #点击保存按钮
        rp.click_save()
        #断言
        text = op.get_redact_succe_text()
        self.assertIn("修改商机信息成功!",text)





