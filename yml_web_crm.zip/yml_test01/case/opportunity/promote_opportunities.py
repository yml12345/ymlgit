"""
推进商机
"""
from case.base_case import BaseCase
from time import sleep
from page.opportunity_page import OpportunityPage
from page.promote_opportunities_page import PromoteOpportunitiesPage
from page.promote_history_page import PromoteHistoryPage
from page.see_opportunity_page import SeeOpportunityPage
from page.add_opportunity_page import AddOpportunityPage
from page.select_customer_page import SelectCustomerPage
import ddt
from common.util import get_data_from_excel
from common.logger import Logger
from common.config import *
logger = Logger().logger


@ddt.ddt
class PromoteOpportunities(BaseCase):
    """推进操作类"""
    @ddt.data(*get_data_from_excel("promote1_opportunities.xlsx"))
    @ddt.unpack
    def test_promote_opportunities(self,opportunity_name,customer,anticipated_price,text,time,content):
        """从商机列表页面点击推进，进行推进操作"""
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(5)
        # 点击对应的查看，进入查看详情页面
        op = OpportunityPage(self.driver)
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        # 点击推进历史,进入推进历史页面
        sop = SeeOpportunityPage(self.driver)
        sop.click_promote_history()
        sleep(5)
        # 在推进历史页面统计推进条数
        php = PromoteHistoryPage(self.driver)
        t1 = len(php.get_tr_list())
        logger.info(t1)
        #点击基本信息
        sop.click_basic_info()
        sleep(3)
        #点击返回按钮
        sop.click_return()
        sleep(3)
        # 点击对应的推进按钮，进入推进页面
        op.click_promote_opportunity(opportunity_name)
        sleep(4)
        #在推进页面填写相关信息
        po = PromoteOpportunitiesPage(self.driver)
        # po.select_ele_phase(text)
        select = po.select(po.select_ele_locator)
        select.select_by_visible_text(text)
        sleep(2)
        po.send_next_contact_time(time)
        po.send_next_content(content)
        po.click_promote()
        # 点击对应的推进按钮，进入推进页面
        op.click_promote_opportunity(opportunity_name)
        sleep(4)
        # 在推进页面填写相关信息
        po = PromoteOpportunitiesPage(self.driver)
        # po.select_ele_phase(text)
        select = po.select(po.select_ele_locator)
        select.select_by_visible_text(text)
        sleep(2)
        po.send_next_contact_time(time)
        po.send_next_content(content)
        po.click_promote()
        #断言
        #点击对应的查看，进入查看详情页面
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        #点击推进历史,进入推进历史页面
        sop = SeeOpportunityPage(self.driver)
        sop.click_promote_history()
        sleep(5)
        #在推进历史页面统计推进条数
        php = PromoteHistoryPage(self.driver)
        t2 = len(php.get_tr_list())
        logger.info(t2)
        sleep(5)
        self.assertNotEqual(t1,t2)

    @ddt.data(*get_data_from_excel("promote2_opportunities.xlsx"))
    @ddt.unpack
    def test_see_ooportunities_promote(self,opportunity_name,customer,anticipated_price,text,time,content):
        """从查看详情页面，点击推进按钮，进行推进操作"""
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(5)
        # 点击对应的查看，进入查看详情页面
        op = OpportunityPage(self.driver)
        op.click_see_opportunity(opportunity_name)
        sleep(4)
        # 点击推进历史,进入推进历史页面
        sop = SeeOpportunityPage(self.driver)
        sop.click_promote_history()
        sleep(5)
        # 在推进历史页面统计推进条数
        php = PromoteHistoryPage(self.driver)
        t1 = len(php.get_tr_list())
        logger.info(t1)
        # 点击基本信息
        sop.click_basic_info()
        sleep(5)
        # 点击推进,进入推进页面
        sop.click_promote()
        sleep(5)
        # 在推进页面填写相关信息
        po = PromoteOpportunitiesPage(self.driver)
        select = po.select(po.select_ele_locator)
        select.select_by_visible_text(text)
        sleep(2)
        po.send_next_contact_time(time)
        po.send_next_content(content)
        po.click_promote()
        # 点击推进,进入推进页面
        sop.click_promote()
        sleep(5)
        # 在推进页面填写相关信息
        po = PromoteOpportunitiesPage(self.driver)
        select = po.select(po.select_ele_locator)
        select.select_by_visible_text(text)
        sleep(2)
        po.send_next_contact_time(time)
        po.send_next_content(content)
        po.click_promote()
        # 断言
        sleep(4)
        # 点击推进历史,进入推进历史页面
        sop = SeeOpportunityPage(self.driver)
        sop.click_promote_history()
        sleep(5)
        # 在推进历史页面统计推进条数
        php = PromoteHistoryPage(self.driver)
        t2 = len(php.get_tr_list())
        logger.info(t2)
        sleep(5)
        self.assertNotEqual(t1, t2)






