"""
导出商机
"""
from case.base_case import BaseCase
from page.opportunity_page import OpportunityPage
from time import sleep
from time import strftime
from common.file import file_exists_path
from page.add_opportunity_page import AddOpportunityPage
from page.select_customer_page import SelectCustomerPage
import ddt
from common.util import get_data_from_excel
from common.logger import Logger
from common.config import *
logger = Logger().logger

@ddt.ddt
class ExportOpportunities(BaseCase):
    """导出商机类"""
    @ddt.data(*get_data_from_excel("export_opportunities.xlsx"))
    @ddt.unpack
    def test_export_opportunities(self,path,customer,opportunity_name, anticipated_price):
        _time = strftime("%Y-%m-%d")
        file = "5kcrm_business_{}.xls".format(_time)
        logger.info(file)
        aop = AddOpportunityPage(self.driver, ADD_OPPORTUNITY_URL)
        aop.open()
        # 输入相关信息
        aop.click_customer()  # 点击客户输入框
        sleep(2)
        scp = SelectCustomerPage(self.driver)
        scp.select_customer(customer)  # 选择客户，并点击确认
        aop.send_business_name(opportunity_name)
        aop.send_anticipated_price(anticipated_price)
        # 点击“保存”按钮
        aop.click_save()
        sleep(5)
        self.driver.refresh()  #页面刷新
        sleep(10)
        #点击"商机工具"按钮
        op = OpportunityPage(self.driver)
        op.click_opportunity_tool()
        #点击导出商机
        op.click_export_opportunities()
        sleep(2)
        alert = op.alert()
        alert.accept()
        sleep(3)
        #断言（如何判断商机信息是否导出成功）
        file_list = os.listdir(path)
        logger.info(file_list)
        self.assertIn(file,file_list)
        #删除导出的文件
        file_exists_path(file,path)




