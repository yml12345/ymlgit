'''
@author: yimeiling
@software: SeleniumTest
@file: permission_assignment.py
@time: 2020/3/19 16:23
@desc:
'''
"""
权限分配
"""
from case.base_case import BaseCase
from page.login_page import LoginPage
from page.index_page import IndexPage
from page.organization_page import OrganizationPage
from page.permission_assignment_page import PermissionAssignmentPage
from time import sleep
from page.user_control_page import UserControlPage
from common.util import get_data_from_excel
import ddt
from common.logger import Logger
from common.config import *

logger = Logger().logger

@ddt.ddt
class PermissionAssignment(BaseCase):
    """
    权限分配
    """

    @ddt.data(*get_data_from_excel("permission_assignment.xlsx"))
    @ddt.unpack
    def test_permission_assignment(self,station,password1):
        """权限分配"""
        p_list = ["合同","财务"]
        op = OrganizationPage(self.driver,PERMISSION_ASSIGNMENT_URL)
        op.open()
        sleep(5)
        #点击授权,进入权限分配页面
        op.click_mandate()
        sleep(5)
        pap = PermissionAssignmentPage(self.driver)
        # p_list = pap.permission_list() #获取权限分配页面的所有权限信息
        sleep(2)
        pap.click_permission(p_list) #进行权限勾选操作
        pap.click_save()
        sleep(2)
        alert = pap.alert()
        alert.accept()
        sleep(5)
        #断言
        # 点击用户管理，进入用户管理页面
        op.click_user_control()
        sleep(5)
        ucp = UserControlPage(self.driver)
        sleep(5)
        user_list = ucp.get_user_text(station)
        user = user_list[-1]
        sleep(5)
        #点击用户下拉框
        ip = IndexPage(self.driver)
        ip.click_user()
        #点击退出
        ip.click_exit()
        sleep(5)
        #进行登录操作
        lp = LoginPage(self.driver)
        lp.login(user, password1)
        sleep(5)
        p1_list = ip.get_menu_text()
        for p in p_list:
            self.assertIn(p,p1_list)
        # 点击用户下拉框
        ip = IndexPage(self.driver)
        ip.click_user()
        # 点击退出
        ip.click_exit()
        sleep(5)
        # 进行登录操作
        lp.login("admin","hd123456")
        sleep(5)














