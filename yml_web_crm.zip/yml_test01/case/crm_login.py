import unittest
import ddt
from page.login_page import LoginPage
from page.index_page import IndexPage
from time import sleep
from common.util import get_data_from_excel
import unittest
from common.driver import chrome
from common.config import *

@ddt.ddt
class CrmLogin(unittest.TestCase):  #以test开头的方法会被识别成用例
    def setUp(self):
        """调用谷歌启动"""
        self.driver = chrome()
        self.driver.get(HOSTS)

    @ddt.data(*get_data_from_excel("userinfo.xlsx"))
    @ddt.unpack
    def test_login(self,username,password):
        lp = LoginPage(self.driver)
        lp.open()
        sleep(4)
        # 输入用户名
        lp.login_username(username)
        sleep(4)
        # 输入密码
        lp.login_password(password)
        #点击登录
        lp.login_buttn()
        #断言
        ip = IndexPage(self.driver)
        name = ip.get_username()
        self.assertEqual(username,name)

    def tearDown(self):
        """关闭浏览器启动"""
        self.driver.quit()








