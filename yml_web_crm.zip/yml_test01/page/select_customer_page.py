"""
选择客户页面
"""
from selenium.webdriver.common.by import By
from page.base_page import BasePage

class SelectCustomerPage(BasePage):
    """选择客户页面操作类"""
    ack_locator = (By.XPATH,"/html/body/div[10]/div[3]/div/button[1]/span")  #“确认”按钮
    tbody_locator = (By.CSS_SELECTOR,"#datas") #
    tr_list_locator = (By.TAG_NAME,"tr")
    td_list_locator = (By.TAG_NAME,"td")
    input_locator = (By.TAG_NAME,"input")

    def click_select_customer(self,customer):
        """
        根据客户名，去选择一个客户，并勾选
        :param customer: 客户名
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            if td_list[1].text == customer:
                self.find_element(self.input_locator,td_list[0]).click()

    def ack_click(self):
        """
        点击“确认”按钮
        :return:
        """
        self.find_element(self.ack_locator).click()
    def select_customer(self,customer):
        """
        选择客户，并点击“确认”
        :param customer:
        :return:
        """
        self.click_select_customer(customer)
        self.ack_click()




