'''
@author: yimeiling
@software: SeleniumTest
@file: permission_assignment_page.py
@time: 2020/3/19 16:26
@desc:
'''
"""
权限分配页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By
from time import sleep

class  PermissionAssignmentPage(BasePage):
    """
    权限分配操作类
    """
    #定义定位器
    tbody_locator = (By.XPATH,'//*[@id="dialog-authorize"]/form/table/tbody')
    tr_list_locator = (By.TAG_NAME,"tr")
    td_list_locator = (By.TAG_NAME,"td")
    input_locator = (By.TAG_NAME,"input")
    save_locator = (By.CSS_SELECTOR,'input[value="保存"]')


    def click_permission(self,p_list):
        """
        勾选p1_list列表中的权限
        :param p_list: 需要勾选的权限
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator, tr)
            b = td_list[1].text
            for i in p_list:
                if i == b:
                    self.find_element(self.input_locator, td_list[0]).click()




    def click_save(self):
        self.find_element(self.save_locator).click()





