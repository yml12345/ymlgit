"""
添加商机页面
"""
from selenium.webdriver.common.by import By
from page.base_page import BasePage

class AddOpportunityPage(BasePage):
    """添加商机页面"""

    #定义定位器
    customer_locator = (By.XPATH, '//*[@id="customer_name"]')   #客户输入框
    business_name_locator = (By.XPATH, "/html/body/div[5]/div[2]/div/form/table/tbody/tr[3]/td[4]/input")  #商机名输入框
    anticipated_price_locator = (By.CSS_SELECTOR, "#estimate_price")  #预计价格输入框
    save_locator = (By.CSS_SELECTOR, "#form1 > table > tfoot > tr > td > input:nth-child(1)")  #保存按钮

    def click_customer(self):
        """点击客户输入框"""
        self.find_element(self.customer_locator).click()

    def send_business_name(self, business_name):
        """
        输入商机名信息
        :param business_name: 商机名
        :return:
        """
        self.find_element(self.business_name_locator).send_keys(business_name)
    def send_anticipated_price(self, anticipated_price):
        """
        输入预计价格
        :param anticipated_price:预计价格
        :return:
        """
        self.find_element(self.anticipated_price_locator).send_keys(anticipated_price)
    def click_save(self):
        """
        点击保存
        :return:
        """
        self.find_element(self.save_locator).click()

