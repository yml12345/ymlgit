"""
商机详情页面
"""
from page.base_page import  BasePage
from selenium.webdriver.common.by import By

class SeeOpportunityPage(BasePage):
    #定义定位器
    opportunity_name_locator = (By.XPATH,'//*[@id="tab1"]/div[2]/table/tbody/tr[4]/td[4]/span') #定位商机名称信息
    promote_history_locator = (By.XPATH,'//*[@id="left_list"]/li[3]/a')  #定位推进历史按钮
    basic_info_locator = (By.LINK_TEXT,"基本信息")  #定位基本信息按钮
    return_locator = (By.XPATH,'//*[@id="tab1"]/div[1]/div/a[3]')  #定位返回按钮
    delete_locator = (By.LINK_TEXT,"删除")  #定位删除按钮
    promote_locator = (By.XPATH,'//*[@id="right_list"]/ul/li[2]/a') #定位“推进”按钮
    task_locator = (By.XPATH,'//*[@id="left_list"]/li[7]/a') # 定位“任务”按钮
    add_task_locator = (By.XPATH,'//*[@id="right_list"]/ul/li[5]/a')  #定位“添加任务”


    def get_opportunity_name_text(self):
        """
        获取商机名
        :return:
        """
        return self.find_element(self.opportunity_name_locator).text

    def click_promote_history(self):
        """
        点击"推进历史"按钮
        :return:
        """
        self.find_element(self.promote_history_locator).click()

    def click_basic_info(self):
        """
        点击"基本信息"
        :return:
        """
        self.find_element(self.basic_info_locator).click()

    def click_return(self):
        """
        点击"返回"按钮
        :return:
        """
        self.find_element(self.return_locator).click()

    def click_delete(self):
        """
        点击"删除"按钮
        :return:
        """
        self.find_element(self.delete_locator).click()

    def click_promote(self):
        """
        点击“推进”按钮
        :return:
        """
        self.find_element(self.promote_locator).click()

    def click_task(self):
        """
        点击“任务”按钮
        :return:
        """
        self.find_element(self.task_locator).click()

    def click_add_task(self):
        """
        点击“添加任务”按钮"""
        self.find_element(self.add_task_locator).click()