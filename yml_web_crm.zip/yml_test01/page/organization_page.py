'''
@author: yimeiling
@software: SeleniumTest
@file: organization_page.py
@time: 2020/3/19 16:28
@desc:
'''
"""
组织架构页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

class OrganizationPage(BasePage):
    """
    组织机构页面操作类
    """
    #定义定位器

    section_locator = (By.XPATH, '//*[@id="browser"]/li/span')  #定位部门
    mandate_locator = (By.LINK_TEXT, "授权") #定位授权按钮
    user_control_locator = (By.LINK_TEXT,"用户管理") #定位用户管理

    def  click_mandate(self):
        action_ele = self.find_element(self.section_locator)
        action = ActionChains(self.driver)
        action.move_to_element(action_ele)
        action.perform()
        self.find_element(self.mandate_locator).click()

    def click_user_control(self):
        """
        用户管理按钮
        :return:
        """
        self.find_element(self.user_control_locator).click()
        # key1 = self.find_element(self.user_control_locator)
        # action = ActionChains(self.driver)
        # action.key_down(key1)
        # action.perform()
        # action.key_up(key1)
        # action.perform()


