'''
@author: yimeiling
@software: SeleniumTest
@file: user_control_page.py
@time: 2020/3/19 19:37
@desc:
'''
"""
用户管理页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By
from common.logger import Logger

logger = Logger().logger

class UserControlPage(BasePage):
    """
    用户管理页面操作类
    """
    #定义定位器
    tbody_locator = (By.XPATH,'//*[@id="user_form"]/div[2]/table/tbody')
    tr_list_locator = (By.XPATH,"tr")
    td_list_locator = (By.XPATH,"td")


    def get_user_text(self,station):
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        user_list = []
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            if td_list[2].text == station:
                user_list.append(td_list[1].text.strip())
        logger.info(user_list)
        return user_list

