"""
添加任务页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By

class AddTaskPage(BasePage):
    """添加任务页面操作类"""

    #定义定位器
    theme_locator = (By.CSS_SELECTOR,"#subject")
    save_locator = (By.CSS_SELECTOR,'input[value="保存"]')

    def send_theme(self,theme_name):
        """输入主题信息"""
        return self.find_element(self.theme_locator).send_keys(theme_name)

    def click_save(self):
        """点击保存按钮"""
        self.find_element(self.save_locator).click()