"""
商机页面
"""
from selenium.webdriver.common.by import By
from page.base_page import BasePage
from common.logger import Logger

logger = Logger().logger

class OpportunityPage(BasePage):
    """
    商机页面操作类
    """
    #定义定位器
    add_opportunity_buttn_locator = (By.XPATH,"/html/body/div[5]/div[2]/div[1]/div/a")   #定位添加商机按钮
    opportunity_text_locator = (By.XPATH,'//*[@id="form1"]/table/tbody/tr[1]/td[4]/a/span')  #定位第一条商机信息中的商机名
    delete_one_opportunity_locator = (By.CSS_SELECTOR, "#form1 > table > tbody > tr > td:nth-child(1) > input")  #定位第一条商机信息前的勾选框
    delete_locator = (By.CSS_SELECTOR,"#delete")  #“删除”按钮
    tbody_locator = (By.XPATH,'//*[@id="form1"]/table/tbody')  #定位tbody
    tr_list_locator = (By.TAG_NAME, "tr")  #定位tbody下的tr标签
    td_list_locator = (By.TAG_NAME, "td")  #定位tr下的td标签
    input_list_locator =(By.TAG_NAME,"input")  #定位勾选框
    next_page_locator = (By.LINK_TEXT,"下一页 »")  #下一页
    option_locator = (By.CSS_SELECTOR,"#td_colspan > div > div:nth-child(3) > select > option")  #统计select下的option个数
    one_page_locator = (By.LINK_TEXT,"首页")  #首页
    recycled_locator = (By.XPATH,"/html/body/div[5]/p/a[14]")  #回收站
    see_opportunity_locator = (By.LINK_TEXT,"查看")  #对应的查看按钮
    promote_opportunity_locator = (By.LINK_TEXT,"推进")  #对应的推进按钮
    redact_locator = (By.LINK_TEXT,"编辑")  #对应的编辑按钮
    opportunity_tool_locator = (By.CSS_SELECTOR,'body > div.container > div.row > div:nth-child(1) > div > div > button')  #商机工具按钮
    export_opportunities_locator = (By.CSS_SELECTOR,"#excelExport")  #定位导出商机
    redact_succe_locator = (By.XPATH,'/html/body/div[5]/div[2]') #定位编辑成功推送信息
    #点击“添加商机”，进入添加商机页面
    def click_add_opportunity_buttn(self):
        """
        点击“添加商机”按钮
        :return:
        """
        self.find_element(self.add_opportunity_buttn_locator).click()

    def click_one_opportunity(self):
        """
        勾选一个商机
        :return:
        """
        self.find_element(self.delete_one_opportunity_locator).click()

    def click_delete(self):
        """
        点击“删除”按钮
        :return:
        """
        self.find_element(self.delete_locator).click()


    def get_opportunity_text(self):
        """
        获取第一行商机名
        :return:
        """
        return self.find_element(self.opportunity_text_locator).text


    def click_more_opportunity(self):
        """
        同时勾选当前页面的所有商品
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            self.find_element(self.input_list_locator,td_list[0]).click()


    def get_opportunity_list(self):
        """ 获取所有的商品信息，并存放到列表中"""
        option_list  = self.find_elements(self.option_locator)
        i=len(option_list)
        opportunity_list =[]
        while i > 0:
            t = self.find_element(self.tbody_locator)
            tr_list = self.find_elements(self.tr_list_locator, t)
            for tr in tr_list:
                td_list = self.find_elements(self.td_list_locator, tr)
                opportunity_list.append(td_list[3].text)  # 将商机名称找出来,并存放到列表中
            i = i-1
            if i > 0:
                self.find_element(self.next_page_locator).click()  #点击下一页
        return opportunity_list


    def click_recycled(self):
        """
        点击回收站
        :return:
        """
        self.find_element(self.recycled_locator).click()

    def click_see_opportunity(self, opportunity_name):
        """
        点击对应的查看按钮
        :param opportunity_name: 根据商机名进行判断
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            if td_list[3].text == opportunity_name:
                return self.find_element(self.see_opportunity_locator,td_list[10]).click()

    def click_redact(self, opportunity_name):
        """
        点击对应的编辑按钮
        :param opportunity_name: 根据商机名进行判断
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator, t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator, tr)
            if td_list[3].text == opportunity_name:
                return self.find_element(self.redact_locator, td_list[10]).click()

    def click_opportunity_tool(self):
        """
        点击商机工具
        :return:
        """
        self.find_element(self.opportunity_tool_locator).click()

    def click_export_opportunities(self):
        """
        点击导出商机
        :return:
        """
        self.find_element(self.export_opportunities_locator).click()

    def click_promote_opportunity(self, opportunity_name):
        """
        点击对应的推进按钮
        :param opportunity_name: 根据商机名进行判断
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            if td_list[3].text == opportunity_name:
                return self.find_element(self.promote_opportunity_locator,td_list[10]).click()

    def get_redact_succe_text(self):
        """
        获取修改成功推送信息
        :return:
        """
        logger.info(self.find_element(self.redact_succe_locator).text)
        return self.find_element(self.redact_succe_locator).text




