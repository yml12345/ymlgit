from selenium.webdriver.common.by import By
from page.base_page import BasePage
from common.logger import Logger

logger = Logger().logger

class IndexPage(BasePage):
    """
    主页面
    """

    #定义定位器
    username_locator = (By.XPATH,"/html/body/div[1]/div/div/div[2]/ul[2]/li[6]/a")
    opportunity_locator = (By.LINK_TEXT,"商机")
    user_locator = (By.XPATH,"/html/body/div[1]/div/div/div[2]/ul[2]/li[6]/a")  #定位用户下拉框
    permission_assignment_locator = (By.LINK_TEXT,"权限分配")  #定位权限分配
    exit_locator = (By.LINK_TEXT,"退出")
    menu_locator = (By.XPATH,'/html/body/div[1]/div/div/div[2]/ul[1]')


    def get_username(self):
        return self.find_element(self.username_locator).text.strip()
    #点击主页中的商机菜单
    def click_opportunity(self):
        """
        点击"商机"菜单
        :return:
        """
        return self.find_element(self.opportunity_locator).click()

    def click_user(self):
        """
        点击用户下拉框
        :return:
        """
        self.find_element(self.user_locator).click()

    def click_permission_assignment(self):
        """点击权限分配"""
        self.find_element(self.permission_assignment_locator).click()

    def click_exit(self):
        """
        点击退出
        :return:
        """
        self.find_element(self.exit_locator).click()

    def get_menu_text(self):
        """获取主页面的菜单信息"""
        logger.info(self.find_element(self.menu_locator).text)
        f = self.find_element(self.menu_locator).text
        with open("f1","w",encoding="utf-8") as f1:
            f1.write(f)
            logger.info(f1)
        data_list = []
        with open("f1", 'r', encoding='utf-8') as f2:
            for i in range(5):
                data = f2.readline()
                data_list.append(data)
        logger.info(data_list)
        data_list = [x.strip() for x in data_list]
        return data_list
