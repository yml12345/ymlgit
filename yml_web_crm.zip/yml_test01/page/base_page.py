"""
所有页面基本操作
"""
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.support.select import Select
from common.config import *


class BasePage():
    """
    所有页面基类
    """
    # HOST = r"http://192.168.0.105/crm"

    def __init__(self,driver,url = HOSTS):
        """
        启动浏览器
        :param driver:
        :param url:
        """
        self.driver = driver
        self.url = url

    def open(self):
        """访问网址"""
        self.driver.get(self.url)
    def quit(self):
        self.driver.quit()

    def find_element(self,locator,element=None):
        """用find_element查找"""
        if element:
            return element.find_element(*locator)
        return self.driver.find_element(*locator)

    def find_elements(self,locator,element=None):
        """用find_elements查找"""
        if element:
            return element.find_elements(*locator)
        return self.driver.find_elements(*locator)

    def alert(self):
        """提示框"""
        return Alert(self.driver)

    def select(self,locator):
        """
        选择框
        :param locator: 定位选择框位置
        :return:
        """
        select_ele = self.driver.find_element(*locator)
        return Select(select_ele)


