"""
任务页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By
from common.logger import Logger

logger = Logger().logger

class TaskPage(BasePage):
    """任务页面操作类"""

    #定义定位器
    tbody_locator = (By.XPATH,'//*[@id="tab4"]/table/tbody')
    tr_list_locator = (By.TAG_NAME,"tr")
    td_list_locator = (By.TAG_NAME,"td")

    def get_td_text(self):
        """
        获取主题名称
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        t_list = []
        for tr in tr_list:
            logger.info(tr)
            td_list = self.find_elements(self.td_list_locator,tr)
            logger.info(td_list)
            t_list.append(td_list[1].text)
        logger.info(t_list)
        return t_list




