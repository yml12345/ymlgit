"""
商机回收站页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By

class RecycledPage(BasePage):
    """商机回收站操作类"""

    #定义定位器
    tbody_locator = (By.XPATH,'//*[@id="form1"]/table/tbody')   #定位tbody
    tr_list_locator = (By.TAG_NAME,"tr")  #定位tbody 中的tr标签
    td_list_locator = (By.TAG_NAME,"td")  #定位tr 中的td标签
    input_locator = (By.TAG_NAME,"input")  #定位勾选框
    delete_locator = (By.CSS_SELECTOR, "#delete")  # “删除”按钮
    option_locator =  (By.CSS_SELECTOR,"#td_colspan > div > div:nth-child(3) > select > option")  #统计select下的option个数
    one_page_locator = (By.LINK_TEXT,"首页")  #首页
    next_page_locator = (By.LINK_TEXT,"下一页 »")  #下一页

    def click_one_recycled(self, opportunity_name):
        """
        根据商机名进行判断，勾选一个商机
        :param opportunity_name: 商机名
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            if td_list[3].text == opportunity_name:
                self.find_element(self.input_locator,td_list[0]).click()

    def click_more_recycled(self):
        """
        同时勾选当前页面的所有商机
        :return:
        """
        t = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,t)
        for tr in tr_list:
            td_list = self.find_elements(self.td_list_locator,tr)
            self.find_element(self.input_locator,td_list[0]).click()

    def click_delete(self):
        """
        点击删除按钮
        :return:
        """
        self.find_element(self.delete_locator).click()

    def get_recycled_list(self):
        """
        获取所有的商机名，并放入列表中
        :return:
        """
        option_list  = self.find_elements(self.option_locator)
        i=len(option_list)
        recycled_list =[]
        while i > 0:
            t = self.find_element(self.tbody_locator)
            tr_list = self.find_elements(self.tr_list_locator, t)
            for tr in tr_list:
                td_list = self.find_elements(self.td_list_locator, tr)
                recycled_list.append(td_list[3].text)  # 将商机名称找出来,并存放到列表中
            i = i-1
            if i > 0:
                self.find_element(self.next_page_locator).click()  #点击下一页
        return recycled_list

