"""
推进历史页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By


class PromoteHistoryPage(BasePage):
    """推进历史页面类"""
    #定义定位器
    tbody_locator = (By.XPATH,'//*[@id="tab8"]/table/tbody')
    tr_list_locator = (By.TAG_NAME,"tr")
    td_list_locator = (By.TAG_NAME,"td")
    tr1_locator = (By.XPATH,'//*[@id="tab8"]/table/tbody/tr[1]')


    def get_tr_list(self):
        """获取推进历史页面中的所有历史信息"""
        tbody = self.find_element(self.tbody_locator)
        tr_list = self.find_elements(self.tr_list_locator,tbody)
        return tr_list










