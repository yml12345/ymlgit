"""
登录页面
"""
from selenium.webdriver.common.by import By
from page.base_page import BasePage

class LoginPage(BasePage):  #继承base_page;
    """
    封装登录页面
    """
    #定义定位器
    username_locator = (By.NAME,"name")   #元素定位方式
    password_locator = (By.NAME,"password")
    button_locator = (By.NAME,"submit")
    def login_username(self,username):
        """
        用户名
        :param username: 输入用户名
        :return:
        """
        self.find_element(self.username_locator).send_keys(username)  #元素的操作
    def login_password(self,password):
        """
        密码
        :param password: 输入密码
        :return:
        """
        self.find_element(self.password_locator).send_keys(password)

    def login_buttn(self):
        """
        点击登录
        """
        self.find_element(self.button_locator).click()
    def login(self,username,password):
        """
        输入用户名、密码，并登录
        :param username: 用户名
        :param password: 密码
        :return:
        """
        self.login_username(username)
        self.login_password(password)
        self.login_buttn()

    def get_cookies(self):
        """
        获取cookies
        :return:
        """
        return self.driver.get_cookies()
