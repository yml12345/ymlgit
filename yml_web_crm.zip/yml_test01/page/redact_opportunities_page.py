"""
 编辑商机页面
"""
from page.base_page import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

class RedactOpportunitiesPage(BasePage):
    """编辑页面操作类"""

    #定义定位器
    opportunity_type_locator = (By.ID, "type")  #定位商机类型选择框
    status_locator = (By.ID, "status_id") #定位选择状态
    save_locator = (By.XPATH, "/html/body/div[5]/div[2]/div/form/table/tfoot/tr/td/input[1]") #定位“保存”按钮




    def click_save(self):
        """
        点击“保存”按钮
        :return:
        """
        self.find_element(self.save_locator).click()

