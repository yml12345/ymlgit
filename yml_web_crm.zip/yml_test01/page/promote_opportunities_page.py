"""
推进商机页面
"""

from page.base_page import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select


class PromoteOpportunitiesPage(BasePage):
    """推进商机类"""
    #定义定位器
    select_ele_locator = (By.NAME,"status_id")  #定位前进阶段选择框
    next_contact_time_locator = (By.ID,"nextstep_time")  #定位下次联系时间
    next_content_locator = (By.ID,"nextstep")   #定位下次联系内容
    by_describing_locator = (By.NAME,"description")  #定位阶段描述输入框
    promote_locator = (By.CSS_SELECTOR,'input[value="推进"]')  #定位“推进”按钮


    def send_next_contact_time(self, time):
        """
        输入下次联系时间
        :param time: 联系时间
        :return:
        """
        return self.find_element(self.next_contact_time_locator).send_keys(time)

    def send_next_content(self, content):
        """
        输入下次联系内容
        :param content: 联系内容
        :return:
        """
        return self.find_element(self.next_content_locator).send_keys(content)
    def send_by_describing(self, description):
        """
        输入阶段描述信息
        :param description: 阶段描述
        :return:
        """
        return self.find_element(self.by_describing_locator).send_keys(description)

    def click_promote(self):
        """
        点击“推进”按钮
        :return:
        """
        self.find_element(self.promote_locator).click()



